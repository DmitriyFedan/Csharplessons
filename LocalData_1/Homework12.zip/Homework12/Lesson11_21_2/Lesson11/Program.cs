﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

using Lesson11.Extensions;

namespace Lesson11
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                //CatchAllErrors();
                //CatchSpecificError();
                //CatchSpecificErrorWithCondition();
                //ExceptionProps();

                //CatchCustomExceptions();
                //CatcherInTheRye();

                //try
                //{
                //    CatcherInTheRye();
                //}
                //catch (Exception ex)
                //{
                //    Console.WriteLine($"Ошибка:{ex.InnerException?.Message}\n{ex.InnerException?.StackTrace}");
                //}

                //UsingPartialClasses();
                //UsingPartialMethods();

                //UsingReflection();
                //GetMethodsViaReflection();
                //GetPropertiesAndFieldsViaReflection();
                //UsingAttributes();
                //UsingReflectionForAssemblyLoad();

                //UsingDynamic();
                //UsingDynamic2();

                //UsingGarbageCollector();
                //UsingDestructors();
                //UsingDisposables();
                //UsingDisposables2();
                //UsingDisposables3();
                //UsingDisposables4();
                WorkingWithUnsafeCode();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Произошла непредвиденная ошибка {ex.Message}\n{ex.StackTrace}"); 
            }

            Console.ReadKey();
        }

        public static void CatchAllErrors()
        {
            try
            {
                int x = 4;
                int y = 0;
                int result = x / y;
                Console.WriteLine($"Результат: {result}");
            }
            catch
            {
                Console.WriteLine("Возникло исключение!");
            }
            finally
            {
                Console.WriteLine("Блок finally");
            }

            Console.WriteLine("Конец программы");
        }

        public static void CatchSpecificError()
        {
            try
            {
                int x = 4;
                int y = 0;
                int result = x / y;
                Console.WriteLine($"Результат: {result}");
            }
            catch (DivideByZeroException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"{ex.Message}:{ex.StackTrace}");
            }
        }

        public static void CatchSpecificErrorWithCondition()
        {
            int x = 4;
            int y = 0;
            try
            {
                int result = x / y;
                Console.WriteLine($"Результат: {result}");
            }
            catch (Exception) when (y == 0)
            {
                Console.WriteLine("y не должен быть равен 0");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        public static void ExceptionProps()
        {
            int x = 4;
            int y = 0;
            try
            {
                int result = x / y;
                Console.WriteLine($"Результат: {result}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Исключение {ex.Message}");
                Console.WriteLine($"Метод {ex.TargetSite}");
                Console.WriteLine($"Трассировка стека {ex.StackTrace}");
                Console.WriteLine($"Источник: {ex.Source}");
            }
        }

        public static void CatchCustomExceptions()
        {
            try
            {
                Person p = new Person("Вася", 20);
                p.Age = -20;
            }
            catch (PersonException ex)
            {
                Console.WriteLine($"Ошибка: {ex.Message}");
            }
        }

        public static void CatcherInTheRye()
        {
            try
            {
                var person = CreatePerson("Вася", -20);
            }
            catch (PersonArgumentException ex)
            {
                Console.WriteLine(ex);
                throw;
                // throw new PersonException(ex.Message, ex);
                //throw ex;// Don't do like this!
            }
        }

        private static Person CreatePerson(string name, int age)
        {
            try
            {
                var person = new Person(name, age);
                return person;

            }
            catch (PersonException ex)
            {
                Console.WriteLine(ex.Message);
                throw new PersonArgumentException("Неверный аргумент!", age, ex);
            }

        }

        public static void UsingPartialClasses()
        {
            Account account = new Account(100);
            
            account.Put(50);
            Console.WriteLine(account.CurrentSum);

            account.Take(25);
            Console.WriteLine(account.CurrentSum);
        }

        public static void UsingPartialMethods()
        {
            Account account = new Account(100);

            account.DoSomething();
        }

        public static void UsingReflection()
        {
 
            Type userType = typeof(User);
            Console.WriteLine(userType);

            User user = new User("Вася", 20);
            Type userType2 = user.GetType();
            Console.WriteLine(userType2);

            Type myType = Type.GetType("Lesson11.User", throwOnError:false, ignoreCase:true);
            Console.WriteLine(myType);

            string nameofUser = nameof(User);
            Console.WriteLine(nameofUser);
        }

        public static void GetMethodsViaReflection()
        {
            Type myType = typeof(User);

            Console.WriteLine("Методы:");
            foreach (MethodInfo method in myType.GetMethods())
            {
                string modificator = "";
                if (method.IsStatic)
                    modificator += "static ";
                if (method.IsVirtual)
                    modificator += "virtual";

                Console.Write($"{modificator} {method.ReturnType.Name} {method.Name} (");
                
                //получаем все параметры
                ParameterInfo[] parameters = method.GetParameters();
                for (int i = 0; i < parameters.Length; i++)
                {
                    Console.Write($"{parameters[i].ParameterType.Name} {parameters[i].Name}");
                    if (i + 1 < parameters.Length) Console.Write(", ");
                }
                Console.WriteLine(")");
            }
        }

        public static void GetPropertiesAndFieldsViaReflection()
        {
            Type myType = typeof(User);

            Console.WriteLine("Поля:");
            foreach (FieldInfo field in myType.GetFields())
            {
                Console.WriteLine($"{field.FieldType} {field.Name}");
            }

            Console.WriteLine("Свойства:");
            foreach (PropertyInfo prop in myType.GetProperties())
            {
                Console.WriteLine($"{prop.PropertyType} {prop.Name}");
            }
        }

        public static void UsingReflectionForAssemblyLoad()
        {
            Assembly asm = Assembly.LoadFrom(@"D:\Projects\Courses\2021_2\Lesson09_21_2\UsingDelegates\bin\Debug\net5.0\UsingDelegates.dll");

            Console.WriteLine(asm.FullName);

            Type[] types = asm.GetTypes();
            foreach (Type t in types)
            {
                Console.WriteLine(t.Name);
            }
        }

        public static void UsingAttributes()
        {
            User user1 = new User("Вася", 35);
            bool isUser1Valid = ValidateUser(user1);
            Console.WriteLine($"Результат валидации {user1.Name}: {isUser1Valid}");

            User user2 = new User("Петя", 16);
            bool isUser2Valid = ValidateUser(user2);
            Console.WriteLine($"Результат валидации {user2.Name}: {isUser2Valid}");

            User user3 = new User("Маша", 17);
            bool isUserAgeValid = ValidateUserAge(user3);
            Console.WriteLine($"Результат валидации возраста {user3.Name}: {isUserAgeValid}");
        }

        private static bool ValidateUser(User user)
        {
            Type t = typeof(User);
            object[] attrs = t.GetCustomAttributes(false);
            foreach (AgeValidationAttribute attr in attrs)
            {
                if (attr != null)
                    return (user.Age >= attr.Age);
            }
            return true;
        }

        private static bool ValidateUserAge(User user)
        {
            Type t = typeof(User);
            var ageProp = t.GetProperty(nameof(User.Age));
            var attrs = ageProp.GetCustomAttributes(typeof(AgeValidationAttribute), false);
            foreach (AgeValidationAttribute att in attrs)
            {
                int age = (int)ageProp.GetValue(user);
                return age >= att.Age;
            }

            return true;
        }

        public static void UsingDynamic()
        {
            dynamic x = 3; // здесь x - int
            Console.WriteLine(x);

            x = "Привет мир"; // x - строка
            Console.WriteLine(x);

            x = new Person() { Name = "Вася", Age = 23 }; // x - объект Person
            Console.WriteLine(x);
        }

        public static void UsingDynamic2()
        {
            dynamic person1 = new DynamicPerson() { Name = "Вася", Age = 27 };
            Console.WriteLine(person1);
            Console.WriteLine(person1.GetSalary(28.09, "int"));

            dynamic person2 = new DynamicPerson() { Name = "Петя", Age = "Двадцать два года" };
            Console.WriteLine(person2);
            Console.WriteLine(person2.GetSalary(30, "string"));
        }

        public static void UsingGarbageCollector()
        {
            Test();
            long totalMemory = GC.GetTotalMemory(false);
            Console.WriteLine($"Сборщик мусора использует {totalMemory} байт");

            // Принудительная сборка мусора
            GC.Collect(); 

            // Приостановка текущего потока до окончания сборки мусора
            GC.WaitForPendingFinalizers();

            totalMemory = GC.GetTotalMemory(false);
            Console.WriteLine($"Сборщик мусора использует {totalMemory} байт");
        }

        private static void Test()
        {
            string s = "s";
            for (int i = 0; i < 10000; i++)
            {
                s += "s";
            }
        }

        public static void UsingDestructors()
        {
            CreatePerson();
            GC.Collect();
        }

        private static void CreatePerson()
        {
            var person = new FinalizingPerson("Вася", 22);
            Console.WriteLine(person.Name);
        }

        public static void UsingDisposables()
        {
            DisposablePerson person = null;
            try
            {
                person = new DisposablePerson { Name = "Вася", Age = 22 };
                Console.WriteLine(person);
            }
            finally
            {
                person?.Dispose();
            }
        }

        public static void UsingDisposables2()
        {
            using (DisposablePerson person = new DisposablePerson { Name="Вася", Age=22})
            {
                Console.WriteLine(person);
            };
            
        }

        public static void UsingDisposables3()
        {
            using (DisposablePerson person = new DisposablePerson { Name = "Вася", Age = 22 })
            {
                Console.WriteLine(person);
                using (DisposablePerson anotherPerson = new DisposablePerson { Name = "Петя", Age = 22 })
                {
                    Console.WriteLine(anotherPerson);//

                };
            };
        }

        public static void UsingDisposables4()
        {
            using var person = new DisposablePerson { Name = "Вася", Age = 22 };

            DisposablePerson anotherPerson = new DisposablePerson { Name = "Петя", Age = 22 } ;

            Console.WriteLine(person);
        }

        unsafe static void WorkingWithUnsafeCode()
        {
            int* x; // определение указателя
            int y = 10; // определяем переменную

            x = &y; // указатель x теперь указывает на адрес переменной y
            Console.WriteLine(*x); // 10

            y = y + 20;
            Console.WriteLine(*x);// 30

            *x = 50;
            Console.WriteLine(y); // переменная y=50
        }

    }
}
