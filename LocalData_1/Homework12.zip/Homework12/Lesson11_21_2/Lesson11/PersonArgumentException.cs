﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lesson11
{
    public class PersonArgumentException : ArgumentException
    {
        public PersonArgumentException() : base() { }

        public PersonArgumentException(string message) : base(message) { }

        public PersonArgumentException(string message, Exception inner) : base(message, inner) { }

        public PersonArgumentException(System.Runtime.Serialization.SerializationInfo info,
            System.Runtime.Serialization.StreamingContext context) : base(info, context) { }

        public int Value { get; }
        public PersonArgumentException(string message, int val) : this(message)
        {
            Value = val;
        }

        public PersonArgumentException(string message, int val, Exception inner) : base(message, inner)
        {
            Value = val;
        }

        public override string ToString()
        {
            return base.ToString() + $"\nValue: {Value}";
        }
    }
}
