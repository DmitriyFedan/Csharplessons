﻿using System;
using System.Collections.Generic;

namespace StringSearcher
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                StringSearcher entitySearcher = new StringSearcher(@"\d+");

                entitySearcher.Request += OnEntitySearcherRequest;

                var searchList = new List<string> { "Вася", "Петя", "45", "95", "Собака", "33" };
                entitySearcher.Search(searchList);
            }
            catch(Exception ex)
            {
                Console.WriteLine($"Произошла непредвиденная ошибка {ex.Message}");
            }


            Console.Read();
        }

        private static void OnEntitySearcherRequest(object sender, StringSearcherArgs e)
        {
            Console.WriteLine(e.FoundEntity);
            e.CancelRequest = true;
        }
    }
}
