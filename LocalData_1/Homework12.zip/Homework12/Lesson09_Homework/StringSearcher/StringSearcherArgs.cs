﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StringSearcher
{
    public class StringSearcherArgs : EventArgs
    {
        public bool CancelRequest { get; set; }

        public string FoundEntity { get; }

        public StringSearcherArgs(string entityName)
        {
            FoundEntity = entityName;
        }
    }
}
