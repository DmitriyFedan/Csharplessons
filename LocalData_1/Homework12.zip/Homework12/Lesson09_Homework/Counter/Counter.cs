﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Counter
{
    class Counter
    {
        public delegate void MessageHandler(int cnt);
        public event MessageHandler OnCount;

        public int X { get; set; } = 77;

        public void Count()
        {
            for (int i = 0; i < 100; i++)
            {
                if (i == X)
                {
                    OnCount?.Invoke(i);
                }
            }
        }
    }
}
