﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Counter
{
    class Handler1
    {
        public void Message(int x)
        {
            Console.WriteLine($"Пора действовать, ведь уже {x}!");
        }
    }
}
