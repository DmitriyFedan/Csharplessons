﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Counter
{
    class Handler2
    {
        public void Message(int x)
        {
            Console.WriteLine($"Точно, уже {x}!");
        }
    }

}
