﻿using System;

namespace PingPong
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Ping ping = new Ping();
                Pong pong = new Pong();

                ping.FirePing += pong.OnGameMove;
                pong.FirePong += ping.OnGameMove;

                ping.Play();
            }
            catch(Exception ex)
            {
                Console.WriteLine($"Произошла непредвиденная ошибка {ex.Message}");
            }
            

            Console.ReadLine();
        }


    }
}
